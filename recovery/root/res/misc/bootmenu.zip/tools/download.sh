#!/sbin/sh

# Ketut P. Kumajaya, May 2013, Sept 2014

# Import dual boot environment setup
. /res/misc/env.sh

/sbin/reboot $DOWNLOADCMD
