#!/sbin/sh

# Ketut P. Kumajaya, May 2013, Sept 2014

echo -n $1 > /.secondrom/media/.defaultrecovery
