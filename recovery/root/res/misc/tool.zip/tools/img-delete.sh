#!/sbin/busybox sh

# Ketut P. Kumajaya,  May 2013
# Ketut P. Kumajaya,  Apr 2014
# Android-Andi @ XDA, Jul 2014 (change to work on Samsung Golden)

if /sbin/busybox [ $(/sbin/busybox mount | /sbin/busybox grep -c "/data") -lt 1 ]; then
  /sbin/mount /data
fi

if /sbin/busybox [ $(/sbin/busybox mount | /sbin/busybox grep "/system" | /sbin/busybox grep -c "loop0") -eq 1 ]; then
  /sbin/umount -d -f /system
fi

if /sbin/busybox [ $(/sbin/busybox losetup | /sbin/busybox grep "system.img" | /sbin/busybox grep -c "loop0") -eq 1 ]; then
  /sbin/busybox losetup -d /dev/block/loop0
fi

if /sbin/busybox [ -f /data/media/.secondrom/system.img ]; then
  /sbin/busybox rm -f /data/media/.secondrom/system.img
fi

if /sbin/busybox [ $(/sbin/busybox mount | /sbin/busybox grep "/cache" | /sbin/busybox grep -c "mmcblk0p24") -eq 1 ]; then
  /sbin/umount /cache
fi

# /sbin/busybox mke2fs -T ext4 -b 4096 -m 0 -J size=16 -O ^resize_inode,^ext_attr,^huge_file /dev/block/mmcblk0p24
# /sbin/busybox tune2fs -c 0 -i 0 /dev/block/mmcblk0p24
# Above command not working properly with SE Linux
/sbin/make_ext4fs -J /dev/block/mmcblk0p24

if /sbin/busybox [ $(/sbin/busybox mount | /sbin/busybox grep -c "/cache") -eq 0 ]; then
  /sbin/mount /cache
fi
