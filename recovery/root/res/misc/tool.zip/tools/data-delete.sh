#!/sbin/sh

# Ketut P. Kumajaya, Apr 2014, Sept 2014

if [ $(/sbin/busybox mount | grep -c "/data") -lt 1 ]; then
  /sbin/mount /data
fi

# Recursive delete /data exclude /data/media
if [ -d /data/media/.secondrom/data ]; then
  cd /data/media/.secondrom/data
  for f in $(ls -a | grep -v ^media$); do
    rm -rf $f
  done
  cd /
fi
