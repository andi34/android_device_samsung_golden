#!/sbin/sh

# Ketut P. Kumajaya, May 2013, Sept 2014

if [ $(/sbin/busybox mount | grep -c "/data") -lt 1 ]; then
  /sbin/mount /data
fi

SECONDROM=1
[ -f /data/media/.secondrom/system.img ] || SECONDROM=0

exit $SECONDROM
