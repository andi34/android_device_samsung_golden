#!/sbin/sh

# Ketut P. Kumajaya: May 2013, Nov 2013, Apr 2014, Sept 2014

# Import dual boot environment setup
. /res/misc/env.sh

if [ $(/sbin/busybox mount | grep -c "/data") -lt 1 ]; then
  /sbin/mount /data
fi

# Force unmount /system and detach from loop device
if [ $(/sbin/busybox mount | grep "/system" | grep -c "loop0") -eq 1 ]; then
  /sbin/umount -d -f /system
fi

# Recheck if system.img already detached from loop device
if [ $(losetup -a | grep "system.img" | grep -c "loop0") -eq 1 ]; then
  losetup -d /dev/block/loop0
fi

if [ -f /data/media/.secondrom/system.img ]; then
  rm -f /data/media/.secondrom/system.img
fi

mkdir -p /data/media/.secondrom
# Create 2GB sparse image
dd if=/dev/zero of=/data/media/.secondrom/system.img bs=1024 seek=$IMGSEEKVALUE count=0

# Associate /dev/block/loop0 with system.img
if [ -f /data/media/.secondrom/system.img ]; then
  losetup /dev/block/loop0 /data/media/.secondrom/system.img
fi

# Create ext4 filesystem without a journal
if [ $(losetup -a | grep "system.img" | grep -c "loop0") -eq 1 ]; then
  /sbin/make_ext4fs -J /dev/block/loop0
  losetup -d /dev/block/loop0
fi
